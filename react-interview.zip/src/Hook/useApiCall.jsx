import {useState} from "react"

/**
 * 
 * @returns : useApiCall hook return the object of states [loading, error, success, data] and a method [apiCall()]
 * @description : Common hook for api call
 */
function useApiCall(){

    const [loading, setLoading] = useState(false); // Request Loding state
    const [error, setError] = useState(null); // Request error state
    const [success, setSuccess] = useState(false); // Request success state
    const [data, setData] = useState({}) // Response data state

    /**
     * Reset all state as default states and set loading to true
     */
    function resetApiStates() {
        setLoading(true)
        setError(null)
        setSuccess(false)
        setData({})
    }

    /**
     * 
     * @param {*} endpoint : API URL/endpoint
     */

    function apiCall(endpoint){
        resetApiStates()
        fetch(endpoint).then(response => response.json()).then(responseData=>{
            setData(responseData);
            setLoading(false);
            setSuccess(true);
        }).catch(responseError=>{
            setLoading(false)
            setError(responseError)
        })
        
    }


    return {loading, error, success, data, apiCall}


}

export default useApiCall