import React from 'react'

const Th = ({children, props}) => {
    return <th {...props}>{children}</th>
}

export default Th
