import React, { useState } from 'react'

const SearchInput = ({onUpdate, onClear}) => {
    
    const [keyword, setKeyword] = useState("");
    function handleSearch(evt){
        const {value} = evt.target
        if(evt.keyCode===13 || evt.key==="Enter"){
            setKeyword(value)
            onUpdate(value)
        }
        else {
            setKeyword(value)
        }
    }

    function onSearch() {
        if(onUpdate){
           onUpdate(keyword) 
        }
        
    }
   
    return (
        <div>
            <input name="search" placeholder="Search" defaultValue={keyword} onKeyUp={handleSearch}/>
            <button onClick={onSearch}>Search</button> or press enter
           
        </div>
            
      
    )
}
export default SearchInput
