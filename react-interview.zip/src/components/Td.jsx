import React from 'react'

const Td = ({children, props}) => {
    return <td {...props}>{children}</td>
}

export default Td
