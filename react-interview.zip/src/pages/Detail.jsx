import React, {useEffect} from 'react'
import Table from '../components/Table'
import Td from '../components/Td'
import Th from '../components/Th'
import Tr from '../components/Tr'
import useApiCall from '../Hook/useApiCall'

const Detail = ({url, hide}) => {

    const {loading, data, apiCall} = useApiCall();
    useEffect(() => {
        
            apiCall(url)
        
    }, [url])

    if(!url){
        return <React.Fragment></React.Fragment>
    }


    return (
    
    <div>
        {
            loading?
            "Loading Detals"
            :
            <React.Fragment>
                <button onClick={hide}>Hide</button>
            <Table>
                <Tr>
                    <Tr>
                        <Th colspan={2}>Details</Th>
                    </Tr>
                </Tr>
                <Tr>
                    <Th>
                        Name
                    </Th>
                    <Td>
                        {data.name}
                    </Td>
                </Tr>
                <Tr>
                    <Th>
                        Gender
                    </Th>
                    <Td>
                        {data.gender}
                    </Td>
                </Tr>
                <Tr>
                    <Th>
                    Height
                    </Th>
                    <Td>
                        {data.height}
                    </Td>
                </Tr>
                <Tr>
                    <Th>
                    Skin Colour
                    </Th>
                    <Td>
                        {data.skin_color}
                    </Td>
                </Tr>
                <Tr>
                    <Th>
                    Eye Colour
                    </Th>
                    <Td>
                        {data.eye_color}
                    </Td>
                </Tr>
            </Table>
            </React.Fragment>
        }
            
        </div>
    )
}

export default Detail
