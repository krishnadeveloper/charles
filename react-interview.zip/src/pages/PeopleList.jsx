import React, { useEffect, useState } from 'react'
import SearchInput from '../components/SearchInput'
import Table from '../components/Table'
import Td from '../components/Td'
import Th from '../components/Th'
import Tr from '../components/Tr'
import useApiCall from '../Hook/useApiCall'
import Detail from './Detail'

const PeopleList = () => {

    const [people, setPeople] = useState([]); // People list data and default is []
    const [next, setNext] = useState(null);
    const [peopleId, setPeopleId] = useState("")
    
    const {loading, data, apiCall} = useApiCall();
    
    function pagination () {
       
        apiCall(next)
    }
    
    useEffect(()=>{
        if(data.hasOwnProperty("results")){
            let allPeople = people && people.length >0 && data.hasOwnProperty("results") ?  [...people, ...data.results] : data.results;
            setNext(data.next)
            setPeople(allPeople)
        }
    }, [data])


    function handleSearch(keyword) {
        if(keyword.trim()!==""){
            setPeople([])
            apiCall(`https://swapi.dev/api/people?search=${keyword}`)
        }
        else {
            setPeople([])
            apiCall("https://swapi.dev/api/people")
        }
    }



    useEffect(()=>{
        apiCall("https://swapi.dev/api/people")
    },[])




    return <div>
        <SearchInput onUpdate={handleSearch} />
    <Table>
        <React.Fragment>
        <Tr>
            <Th>Name</Th>
            <Th>Gender</Th>
            <Th>Hight</Th>
            <Th>Skin Color</Th>
            <Th>Eye Color</Th>
            <Th>Action</Th>
            
        </Tr>
        {
            (people.length===0 && loading)?
            <Tr colspan={9}>
                Loading
            </Tr>
            :
            people.length>0 && people.map((person, keyId)=><Tr key={keyId}>
                <Td>{person.name}</Td>
                <Td>{person.gender}</Td>
                <Td>{person.height}</Td>
                <Td>{person.skin_color}</Td>
                <Td>{person.eye_color}</Td>
                <Td>
                    {
                        (peopleId === person.url)?
                        <button style={{backgroundColor:"red", color:"white", border:"none"}} onClick={()=>setPeopleId("")}>Hide</button>
                        :
                        <button onClick={()=>setPeopleId(person.url)}>View</button>
                    }
                    
                </Td>
            </Tr>)
            

        }

        {
            (people.length> 0 && loading)?
            <Tr colspan={9}>
                Loading
            </Tr>
            : 
            next !==null && <button onClick={pagination}>more...</button>
        }
        </React.Fragment>
    </Table>
    {peopleId && <Detail url={peopleId} hide={()=>setPeopleId("")}/>}
    </div>
}

export default PeopleList
