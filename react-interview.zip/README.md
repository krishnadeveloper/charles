# React Code Challenge

Requirements

- NodeJS
- VSCode
- Git



- run
    - `npm install`
    - `npm start`

